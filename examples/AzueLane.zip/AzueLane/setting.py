﻿#coding=utf-8

#火力部件为0，空域部件为1
escort = 0
#刷关次数：
repetition = 10
#识别精度
treshold = 0.85
#演习主力舰队战力：
major_power = 10000	
#演习先锋舰队战力：
pioneer_power = 10000
