﻿#coding=utf-8

import Azur_Lane as oaa
#import develop as dev

"""
oaa.find_and_start()    #刷关
oaa.exercises()         #演习
oaa.daily_challenge()   #每日挑战
"""

oaa.exercises()